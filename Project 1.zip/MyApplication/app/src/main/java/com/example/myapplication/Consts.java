package com.example.myapplication;

public class Consts {

    public static final String HEART_RATE_COL = "m_heart_rate";
    public static final String RESPIRATORY_RATE_COL = "m_respiratory_rate";
    public static final String Fever = "fever";
    public static final String Muscle_Ache = "muscle_ache";
    public static final String Loss_of_smell_or_taste = "loss_of_smell_or_taste";
    public static final String Cough = "cough";
    public static final String Nausea = "nausea";
    public static final String Headache = "headache";
    public static final String Diarrhea = "diarrhea";
    public static final String Soar_Throat = "soar_throat";
    public static final String Shortness_of_Breath = "shortness_of_breath";
    public static final String Feeling_tired = "feeling_tired";

}
